from sklearn.neighbors import KNeighborsClassifier
import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime
from win32com.client import Dispatch

def speak(str1):
    speaker = Dispatch(("SAPI.SpVoice"))
    speaker.speak(str1)

def check_if_exists(value):
    try:
        with open("Votes.csv", "r") as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                if row and row[0] == value:
                    return True
    except FileNotFoundError:
        pass
    return False

def record_vote(name, party, date, timestamp):
    col_names = ['NAME', 'VOTE', 'DATE', 'TIME']
    exists = os.path.isfile("Votes.csv")
    with open("Votes.csv", "a", newline='') as csvfile:
        writer = csv.writer(csvfile)
        if not exists:
            writer.writerow(col_names)
        writer.writerow([name, party, date, timestamp])

# ---- Load face data ----
video = cv2.VideoCapture(0)
facedetect = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

if not os.path.exists('data/'):
    os.makedirs('data/')

with open('data/names.pkl', 'rb') as f:
    LABELS = pickle.load(f)

with open('data/faces.pkl', 'rb') as f:
    FACES = pickle.load(f)

FACES = np.array(FACES, dtype='float32')
FACES = FACES.reshape(len(FACES), -1)
LABELS = np.array(LABELS)

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

imgBackground = cv2.imread("background.png")

already_voted_printed = False  # To avoid spamming the console

# ---- Main Loop ----
while True:
    ret, frame = video.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    detected_name = None
    date = ""
    timestamp = ""

    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
        output = knn.predict(resized_img)
        detected_name = output[0]

        ts = time.time()
        date = datetime.fromtimestamp(ts).strftime("%d-%m-%y")
        timestamp = datetime.fromtimestamp(ts).strftime("%H:%M:%S")

        cv2.rectangle(frame, (x, y), (x+w, y+h), (50, 50, 255), 2)
        cv2.putText(frame, str(detected_name), (x, y-15),
                    cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)

        # Show "already voted" warning on camera
        if check_if_exists(detected_name):
            cv2.putText(frame, "ALREADY VOTED!", (x, y+h+25),
                        cv2.FONT_HERSHEY_COMPLEX, 0.7, (0, 0, 255), 2)
            if not already_voted_printed:
                print("YOU HAVE ALREADY VOTED")
                already_voted_printed = True

    # Place frame on background if available
    if imgBackground is not None:
        h_bg, w_bg = imgBackground.shape[:2]
        h_fr, w_fr = frame.shape[:2]
        # Make sure frame fits in background
        if 370 + h_fr <= h_bg and 225 + w_fr <= w_bg:
            imgBackground[370:370+h_fr, 225:225+w_fr] = frame
            cv2.imshow('Smart Voting System', imgBackground)
        else:
            cv2.imshow('Smart Voting System', frame)
    else:
        cv2.imshow('Smart Voting System', frame)

    k = cv2.waitKey(1)

    # Voting logic - only if a face is detected
    if detected_name is not None:
        voter_exist = check_if_exists(detected_name)

        if not voter_exist:
            party = None
            if k == ord('1'):
                party = "BJP"
            elif k == ord('2'):
                party = "CONGRESS"
            elif k == ord('3'):
                party = "AAP"
            elif k == ord('4'):
                party = "NOTA"

            if party is not None:
                speak("YOUR VOTE HAS BEEN RECORDED")
                record_vote(detected_name, party, date, timestamp)
                speak("THANK YOU FOR PARTICIPATING IN THE ELECTION")
                print(f"Vote recorded: {detected_name} -> {party}")
                time.sleep(2)
                break

    if k == ord('q'):
        break

video.release()
cv2.destroyAllWindows()